#version 460 compatibility
#define SH_TEXTURED
#define SH_LIT
#include "/vert/common.glsl"