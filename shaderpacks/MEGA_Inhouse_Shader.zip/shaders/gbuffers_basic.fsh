#version 460 compatibility
#define SH_LIT
#define SH_WORLD
#include "/frag/common.glsl"