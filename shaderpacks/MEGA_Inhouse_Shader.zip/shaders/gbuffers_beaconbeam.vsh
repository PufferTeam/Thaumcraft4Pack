#version 460 compatibility
#define SH_TEXTURED
#define SH_WORLD
#include "/vert/common.glsl"