#version 460 compatibility
#define SH_TEXTURED
#define SH_LIT
#define SH_TERRAIN
#define SH_WORLD
#include "/vert/common.glsl"