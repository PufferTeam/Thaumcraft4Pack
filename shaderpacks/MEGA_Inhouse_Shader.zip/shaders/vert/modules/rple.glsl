#ifndef INC_RPLE
#define INC_RPLE
out RpleInfo {
    #ifdef RPLE
    vec2 lmcoordRed;
    vec2 lmcoordGreen;
    vec2 lmcoordBlue;
    #else
    vec2 lmcoord;
    #endif
} rple;

// Internally sets the light map coordinates into `lmcoordRed`, `lmcoordGreen` and `lmcoordBlue`.
void RPLE_setLightMapCoordinates() {
#ifdef RPLE
    rple.lmcoordRed = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    rple.lmcoordGreen = (gl_TextureMatrix[6] * gl_MultiTexCoord6).st;
    rple.lmcoordBlue = (gl_TextureMatrix[7] * gl_MultiTexCoord7).st;
#else
    rple.lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
#endif
}

#endif //INC_RPLE