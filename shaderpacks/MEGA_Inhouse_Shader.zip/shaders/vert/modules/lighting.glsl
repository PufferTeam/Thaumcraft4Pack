#ifndef INC_LIGHTING
#define INC_LIGHTING
#include "/common/lighting.glsl"

TBN TBN_create(mat3 normalMatrix, vec3 normal, vec4 tangent) {
    vec3 geoNormal = normalize(normalMatrix * normal);
    vec3 geoTangent = normalize(normalMatrix * tangent.xyz);
    vec3 geoBitangent = normalize(normalMatrix * cross(tangent.xyz, normal) * tangent.w);
    return TBN(geoTangent, geoBitangent, geoNormal);
}

#ifdef SH_TEXTURED

TexCoordVsh TexCoords_create(vec2 texCoord, vec2 midCoord, vec2 edgeTexCoord) {
    vec4 bounds;
    vec2 pos;
    if (midCoord != edgeTexCoord) {
        bounds.pq = (midCoord - edgeTexCoord) * 2;
        bounds.st = edgeTexCoord;

        pos = (texCoord - edgeTexCoord) / bounds.pq;
    } else {
        pos = texCoord;
        bounds = vec4(0);
    }
    return TexCoordVsh(pos, bounds);
}

#endif

#endif //INC_LIGHTING
