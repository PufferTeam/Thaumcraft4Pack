#include "/common/settings.glsl"
#include "/common/matrices.glsl"
#include "/vert/modules/rple.glsl"
#include "/vert/modules/lighting.glsl"
#include "/common/main.glsl"
#include "/common/materials.glsl"

out Info info;
out flat uint material;

#ifdef SH_TEXTURED
attribute vec4 mc_midTexCoord;
attribute vec4 mc_Entity;
attribute vec4 rple_edgeTexCoord;
#endif //SH_TEXTURED

attribute vec4 at_tangent;

void main() {
    RPLE_setLightMapCoordinates();

    info.tbn = TBN_create(mat3(gl_NormalMatrix), gl_Normal, at_tangent);

    #ifdef SH_TEXTURED
    mat4 textureMatrix = gl_TextureMatrix[0];

    vec2 texCoord = (textureMatrix * gl_MultiTexCoord0).xy;
    vec2 midTexture = (textureMatrix * mc_midTexCoord).xy;
    vec2 edgeTexture = (textureMatrix * rple_edgeTexCoord).xy;

    info.texCoords = TexCoords_create(texCoord, midTexture, edgeTexture);
    #endif



    #ifdef SH_WATER
    if (mc_Entity.x == MAPPING_WATER) {
        material = MATERIAL_WATER;
    } else
    #endif
    {
        material = MATERIAL_GENERIC;
    }

    info.color = gl_Color;
    vec4 clipPos = ftransform();
    info.viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

    gl_Position = clipPos;
}