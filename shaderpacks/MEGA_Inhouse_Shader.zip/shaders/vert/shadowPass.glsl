#include "/common/settings.glsl"
#include "/common/shadow.glsl"
out Data {
    vec4 color;
    vec2 texCoord;
};

void main() {
    color = gl_Color;
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    vec4 shadowClipPos = ftransform();
    gl_Position = shadowClipDistort(shadowClipPos);
}