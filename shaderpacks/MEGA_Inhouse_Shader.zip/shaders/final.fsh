#version 460 compatibility

#include "/common/settings.glsl"

/* #### Adjustable Variables #### */

/* #### Variables #### */

uniform sampler2D gcolor;

varying vec2 texcoord;

/* #### Functions #### */

/* #### Includes #### */

#include "/postprocess/tonemap.glsl"

/* #### VoidMain #### */

void main() {
    vec3 color = texture2D(gcolor, texcoord).rgb;

    // Tonemapping

    #if TONEMAP == 2
				color.rgb = BOTWTonemap(color.rgb);
    #elif TONEMAP == 3
				color.rgb = BWTonemap(color.rgb);
    #elif TONEMAP == 4
				color.rgb = NegativeTonemap(color.rgb);
    #elif TONEMAP == 5
				color.rgb = SpoopyTonemap(color.rgb);
    #elif TONEMAP == 6
				color.rgb = BSLTonemap(color.rgb);
    color.rgb = colorSaturation(color.rgb);
    #else
				color.rgb = BetterColors(color.rgb);
    color.rgb = color.SWIZZLE;
    #endif

    #ifdef lensMonochrome
				float brightness = dot(color.rgb, vec3(0.299, 0.587, 0.114)); // or (color.r + color.g + color.b) / 3
    vec3 tint = vec3(lMonoRed, lMonoGreen, lMonoBlue) / 255; // or vec3(1.0) - vec3(red, green, blue), idk how you want it
    color.rgb = mix(color.rgb, vec3(brightness * tint.r, brightness * tint.g, brightness * tint.b), lMonoAlpha);
    #endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0); //gcolor
}