#ifndef INC_RPLE
#define INC_RPLE

in RpleInfo {
    #ifdef RPLE
    vec2 lmcoordRed;
    vec2 lmcoordGreen;
    vec2 lmcoordBlue;
    #else
    vec2 lmcoord;
    #endif
} rple;

#ifdef RPLE

// Set in RPLE any time a shader would have a `lightmap` uniform.
uniform sampler2D redLightMap;
uniform sampler2D greenLightMap;
uniform sampler2D blueLightMap;

#else

uniform sampler2D lightmap;

#endif

vec4 RPLE_blockColor() {
    #ifdef RPLE
    vec4 redLight = texture2D(redLightMap, vec2(rple.lmcoordRed.x, 0));
    vec4 greenLight = texture2D(greenLightMap, vec2(rple.lmcoordGreen.x, 0));
    vec4 blueLight = texture2D(blueLightMap, vec2(rple.lmcoordBlue.x, 0));
    return pow(redLight * greenLight * blueLight, vec4(vec3(0.7), 1.0));
    #else
    return texture2D(lightmap, rple.lmcoord);
    #endif
}

vec4 RPLE_skyColor() {
    #ifdef RPLE
    vec4 redLight = texture2D(redLightMap, vec2(0, rple.lmcoordRed.y));
    vec4 greenLight = texture2D(greenLightMap, vec2(0, rple.lmcoordGreen.y));
    vec4 blueLight = texture2D(blueLightMap, vec2(0, rple.lmcoordBlue.y));
    return pow(redLight * greenLight * blueLight, vec4(vec3(0.7), 1.0));
    #else
    return texture2D(lightmap, rple.lmcoord);
    #endif
}
// Returns the coloured light value of the current block light.
vec4 RPLE_blockLight() {
    #ifdef RPLE
    vec4 redLight = texture2D(redLightMap, rple.lmcoordRed);
    vec4 greenLight = texture2D(greenLightMap, rple.lmcoordGreen);
    vec4 blueLight = texture2D(blueLightMap, rple.lmcoordBlue);
    return redLight * greenLight * blueLight;
    #else
    return texture2D(lightmap, rple.lmcoord);
    #endif
}

#endif //INC_RPLE