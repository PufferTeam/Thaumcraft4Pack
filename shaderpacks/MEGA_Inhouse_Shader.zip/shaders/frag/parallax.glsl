#ifndef INC_PARALLAX
#define INC_PARALLAX
#include "/common/lighting.glsl"
#include "/common/settings.glsl"
#ifdef SH_WATER
#include "/frag/water.glsl"
#endif
#include "/common/materials.glsl"

vec2 Parallax_p_distortion(sampler2D tex) {
    ivec2 dim = textureSize(tex, 0);
    vec2 res = vec2(float(dim.x), float(dim.y));

    res /= min(res.x, res.y);
    return res;
}

vec2 Parallax_p_undistort(vec2 prxDim, vec4 bounds, vec2 vw) {
    vec2 undistort = (prxDim * bounds.pq) / max(bounds.p, bounds.q);
    return vw * undistort.yx;
}

TexCoordsAtlas Parallax_get(sampler2D tex, sampler2D normals, TexCoordsLocal texCoords, vec3 viewDirTexSpace, float dist, out float depth, vec3 sunDirTexSpace, uint material) {
    TexCoordsLocal current = texCoords;
    if (current.bounds == vec4(0)) {
        depth = 0.0;
        TexCoordsAtlas result;
        result.pos = current.pos;
        result.dcdx = current.dcdx;
        result.dcdy = current.dcdy;
        return result;
    }
    if (material == MATERIAL_TEXT) {
        depth = 0.0;
        return TexCoordsAtlas_fromLocalDirect(current);
    }
    float baseDepthValue = TexCoordsLocal_sampleClamp(normals, current).a;
    if (dist >= parallaxFadeEnd) {
        depth = 1.0 - baseDepthValue;
        return TexCoordsAtlas_fromLocalClamp(texCoords);
    }
    float parallaxFade = smoothstep(parallaxFadeStart, parallaxFadeEnd, dist);
    float sampleStep = 1.0 / parallaxLayers;
    float currentStep = 1.0;
    vec2 scaledDir = Parallax_p_undistort(Parallax_p_distortion(tex), current.bounds, viewDirTexSpace.xy) * parallaxDepth / -viewDirTexSpace.z;
    vec2 stepDir = scaledDir * sampleStep * (1.0 - parallaxFade);

    float currentDepth = baseDepthValue;

    for (int i = 0; i < parallaxLayers; i++) {
        if (currentStep <= currentDepth) break;
        current.pos += stepDir;
        //        texCoord = fract(texCoord - stepDir);
        currentDepth = TexCoordsLocal_sampleClamp(normals, current).a;
        currentStep -= sampleStep;
    }
    depth = 1.0 - currentStep;
    return TexCoordsAtlas_fromLocalClamp(current);
}

#endif