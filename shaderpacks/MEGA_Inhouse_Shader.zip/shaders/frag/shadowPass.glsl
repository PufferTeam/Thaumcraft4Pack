
uniform sampler2D gtexture;

in Data {
    vec4 color;
    vec2 texCoord;
} data_in;

void main() {
    vec4 color = data_in.color;
    color *= texture2D(gtexture, data_in.texCoord);

    gl_FragData[0] = color;
}