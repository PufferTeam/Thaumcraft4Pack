#ifndef INC_WATER
#define INC_WATER
#include "/common/math.glsl"
#include "/common/time.glsl"

#define WATER_PIXEL 0 //[0 16 32 64 128]
 #define WATER_PARALLAX
#define WATER_SHARPNESS 0.5 //[0.8 0.5 0.2]
#define WATER_NORMALS 1 //[0 1 2]
#define WATER_DETAIL 0.25 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]
#define WATER_SPEED 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 3.50 4.00]
#define WATER_BUMP 1.25 //[0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00]



float Water_p_getHeightMap(in sampler2D noiseTex, vec3 worldPos, vec2 offset) {
    float noise = 0.0;

    vec2 wind = vec2(frameTimeCounter) * 0.5 * WATER_SPEED;

    worldPos.xz += worldPos.y * 0.2;

    #if WATER_NORMALS == 1
	offset /= 256.0;
    float noiseA = texture2D(noiseTex, (worldPos.xz - wind) / 256.0 + offset).g;
    float noiseB = texture2D(noiseTex, (worldPos.xz + wind) / 48.0 + offset).g;
    #elif WATER_NORMALS == 2
	offset /= 256.0;
    float noiseA = texture2D(noiseTex, (worldPos.xz - wind) / 256.0 + offset).r;
    float noiseB = texture2D(noiseTex, (worldPos.xz + wind) / 96.0 + offset).r;
    noiseA *= noiseA; noiseB *= noiseB;
    #endif

    #if WATER_NORMALS > 0
	noise = mix(noiseA, noiseB, WATER_DETAIL);
    #endif

    return noise * WATER_BUMP;
}

vec3 Water_p_getParallax(in sampler2D noiseTex, vec3 worldPos, vec3 viewVector, float dist) {
    vec3 parallaxPos = worldPos;

    for(int i = 0; i < 4; i++) {
        float height = -1.25 * Water_p_getHeightMap(noiseTex, parallaxPos, vec2(0.0)) + 0.25;
        parallaxPos.xz += height * viewVector.xy / dist;
    }
    return parallaxPos;
}

vec2 Water_getNormal(in sampler2D noiseTex, vec3 worldPos, vec3 viewPos, vec3 viewVector, vec3 geoNormal, float dist) {
    vec3 waterPos = worldPos;

    #if WATER_PIXEL > 0
	waterPos = floor(waterPos * WATER_PIXEL) / WATER_PIXEL;
    #endif

    #ifdef WATER_PARALLAX
	waterPos = Water_p_getParallax(noiseTex, waterPos, viewVector, dist);
    #endif

    float normalOffset = WATER_SHARPNESS;

    float fresnel = pow(clamp(1.0 + dot(normalize(geoNormal), normalize(viewPos)), 0.0, 1.0), 8.0);
    float normalStrength = 0.35 * (1.0 - fresnel);

    float h1 = Water_p_getHeightMap(noiseTex, waterPos, vec2( normalOffset, 0.0));
    float h2 = Water_p_getHeightMap(noiseTex, waterPos, vec2(-normalOffset, 0.0));
    float h3 = Water_p_getHeightMap(noiseTex, waterPos, vec2(0.0,  normalOffset));
    float h4 = Water_p_getHeightMap(noiseTex, waterPos, vec2(0.0, -normalOffset));

    float xDelta = (h2 - h1) / normalOffset;
    float yDelta = (h4 - h3) / normalOffset;

    return vec2(xDelta, yDelta) * normalStrength;
}
#endif