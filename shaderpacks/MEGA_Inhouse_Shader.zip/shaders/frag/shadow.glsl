#ifndef INC_SHADOW
#define INC_SHADOW

#include "/common/shadow.glsl"

#include "/common/space.glsl"
#include "/common/math.glsl"

#ifdef OPT_SHADOWS
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
#endif

uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

const uint SHADOW_OFFSETS = 12;
const float SHADOW_OFFSET_COUNT_MULTIPLIER = 1.0 / float(SHADOW_OFFSETS);

vec2 shadowOffsets[SHADOW_OFFSETS] = vec2[SHADOW_OFFSETS](
vec2(0.203125, 0),
vec2(-0.261719, 0.238281),
vec2(0.0390625, -0.457031),
vec2(0.328125, 0.425781),
vec2(-0.605469, -0.109375),
vec2(0.570312, -0.363281),
vec2(-0.191406, 0.707031),
vec2(-0.367188, -0.703125),
vec2(0.789062, 0.285156),
vec2(-0.824219, 0.335938),
vec2(0.394531, -0.847656),
vec2(0.289062, 0.933594)
);

vec3 shadowViewFromFeet(vec3 feetPlayerPos) {
    return (shadowModelView * vec4(feetPlayerPos, 1.0)).xyz;
}

vec4 shadowClipFromShadowView(vec3 shadowViewPos) {
    return shadowProjection * vec4(shadowViewPos, 1.0);
}

vec3 shadowScreenFromFeet(vec3 feetPlayerPos) {
    vec3 shadowViewPos = shadowViewFromFeet(feetPlayerPos);
    vec4 shadowClipPos = shadowClipFromShadowView(shadowViewPos);
    shadowClipPos = shadowClipDistort(shadowClipPos);
    vec3 shadowScreenSpace = screenFromNdc(ndcFromClip(shadowClipPos));
    return shadowScreenSpace;
}

// Pixel-aligned shadows
vec3 shadowWorldGrid(vec3 feetPlayerPos) {
    return feetFromWorld((floor(worldFromFeet(feetPlayerPos) * 32.0 + 0.01) + 0.5) / 32.0);
}

vec3 shadowColorMultiplier(vec3 screenPos, vec3 feetPlayerPos, vec3 normalWorldSpace, vec3 skyLight) {
    vec3 shadowMultiplier;
    #ifdef OPT_SHADOWS
    float dist = length(feetPlayerPos);

    if (dist < shadowDistance) {
        feetPlayerPos = (feetPlayerPos + shadowCheckSurfaceNormalBias * normalWorldSpace);
        vec3 shadowScreenPos = shadowScreenFromFeet(feetPlayerPos);
        if (shadowScreenPos.x < 0 || shadowScreenPos.y < 0 || shadowScreenPos.x >= 1.0 || shadowScreenPos.y >= 1.0 ||
        shadowScreenPos.z < -1.0 || shadowScreenPos.z >= 1.0) {
            return skyLight;
        }
        shadowMultiplier = vec3(0.0);
        float depth = shadowScreenPos.z - shadowCheckDepthBias - shadowCheckPlayerDistanceBias * dist;
        vec2 texelSize = vec2(1.0 / shadowMapResolution);
        float shadow0 = 0.0;
        float shadowFade = smoothstep(shadowDistanceFadeStart, shadowDistance, dist);
        float jitter;
        uint offsets;
        float mult;
        if (dist > shadowDistanceHighQuality) {
            offsets = 1;
            mult = 1;
            jitter = 0.0;
        } else {
            offsets = SHADOW_OFFSETS;
            mult = SHADOW_OFFSET_COUNT_MULTIPLIER;
            jitter = rand2(screenPos.xy) + rand2(shadowScreenPos.xy);
        }

        //Opaque-only shadow prepass
        for (uint i = 0; i < offsets; i++) {
            vec2 offset = rotate(shadowOffsets[i].xy, jitter) * texelSize;
            vec2 fragPos = shadowScreenPos.xy + offset;
            shadow0 += step(depth, texture2D(shadowtex0, fragPos + offset).r);
        }
        shadow0 *= mult;
        shadow0 = max(shadow0, shadowFade);
        if (shadow0 < 0.999) {
            //Colored shadow pass
            for (uint i = 0; i < offsets; i++) {
                vec2 offset = rotate(shadowOffsets[i].xy, jitter) * texelSize;
                vec2 fragPos = shadowScreenPos.xy + offset;
                vec3 shadowColSample = texture2D(shadowcolor0, shadowScreenPos.xy).rgb *
                step(depth, texture2D(shadowtex1, fragPos).r);
                shadowMultiplier += shadowColSample;
            }
            shadowMultiplier *= mult;
        }
        shadowMultiplier = shadowMultiplier * (1.0 - shadow0) + shadow0;
    } else {
        shadowMultiplier = vec3(1.0);
    }
    shadowMultiplier *= skyLight;
    #else
    shadowMultiplier = skyLight;
    #endif

    return shadowMultiplier;
}
vec3 shadowColorMultiplier(vec3 screenPos, vec3 feetPlayerPos, vec3 normalWorldSpace, vec3 skyLight);

#endif //INC_SHADOW