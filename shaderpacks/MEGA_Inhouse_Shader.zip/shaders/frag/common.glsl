#include "/common/main.glsl"
#include "/frag/lighting.glsl"
in Info info;

in flat uint material;

void main() {
    TexCoordsLocal texCoords;
    #ifdef SH_TEXTURED
    texCoords = TexCoordsLocal_fromVsh(info.texCoords);
    #endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = Lighting_directional(
        info.tbn,
        texCoords,
        info.color,
        info.viewPos,
        material
    ); //gcolor
}