#ifndef INC_LIGHTING
#define INC_LIGHTING

#include "/common/lighting.glsl"
#include "/common/matrices.glsl"
#include "/common/space.glsl"
#include "/common/materials.glsl"
#ifdef SH_WATER
#include "/frag/water.glsl"
#endif
#include "/frag/rple.glsl"
#include "/frag/shadow.glsl"
#include "/frag/pbr.glsl"

#ifdef SH_TEXTURED
#include "/frag/parallax.glsl"
uniform sampler2D texture;
uniform sampler2D normalTex;
uniform sampler2D specularTex;
#endif
uniform sampler2D depthtex0;
#ifdef SH_WATER
uniform sampler2D noisetex;
#endif

uniform vec3 shadowLightPosition;

uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float timeAngle;
uniform float shadowFade;


vec3 TBN_mul_elem(mat4 matrix, vec3 vec) {
    return normalize((matrix * vec4(vec, 0.0)).xyz);
}

TBN TBN_mul(mat4 matrix, TBN tbn) {
    return TBN(
    TBN_mul_elem(matrix, tbn.tangent),
    TBN_mul_elem(matrix, tbn.bitangent),
    TBN_mul_elem(matrix, tbn.normal)
    );
}

TexCoordsLocal TexCoordsLocal_fromVsh(TexCoordVsh vsh) {
    TexCoordsLocal result;
    result.pos = vsh.pos;
    result.bounds = vsh.bounds;
    if (vsh.bounds == vec4(0.0)) {
        result.dcdx = dFdx(vsh.pos);
        result.dcdy = dFdy(vsh.pos);
    } else {
        vec2 baseCoord = vsh.pos * vsh.bounds.pq + vsh.bounds.st;
        result.dcdx = dFdx(baseCoord);
        result.dcdy = dFdy(baseCoord);
    }
    return result;
}

vec3 Lighting_p_worldNormalFromSurface(mat3 tbn, vec2 surface, vec3 worldGeoNormal) {
    if (length(surface) > 1.0) {
        surface = normalize(surface);
    }
    vec3 normalMap;
    normalMap.xy = surface;
    normalMap.z = sqrt(1.0 - dot(surface, surface));
    normalMap = normalize(clamp(normalMap, vec3(-1.0), vec3(1.0)));
    vec3 finalNormal = clamp(normalize(normalMap * tbn), vec3(-1.0), vec3(1.0));
    if (finalNormal != finalNormal) {
        return worldGeoNormal;
    }
    return finalNormal;
}

vec3 Lighting_p_getNormalFromTexture(TexCoordsAtlas texCoord, mat3 tbn, vec3 worldGeoNormal, out float ao) {
    #ifdef SH_TEXTURED
    vec4 normalTex = TexCoordsAtlas_sample(normalTex, texCoord);
    vec2 normalSurface = normalTex.rg * 2.0 - 1.0;
    if (normalSurface.x + normalSurface.y > -1.999) {
        ao = normalTex.b;
    } else {
        normalSurface = vec2(0.0);
        ao = 1.0;
    }
    return Lighting_p_worldNormalFromSurface(tbn, normalSurface, worldGeoNormal);
    #else
    return worldGeoNormal;
    #endif
}

void Lighting_p_getMaterialProperties(TexCoordsAtlas texCoord, vec3 albedo, uint material, out float roughness, out float metallic, out vec3 reflectance, out float emissive) {
    if (material == MATERIAL_TEXT) {
        roughness = 1.0;
        metallic = 0.0;
        reflectance = vec3(0.0);
        emissive = 0.0;
        return;
    }
    #ifdef SH_TEXTURED
    vec4 specularData = TexCoordsAtlas_sample(specularTex, texCoord);
    float perceptualSmoothness = specularData.r;
    if (specularData.g * 255 > 229) {
        metallic = 1.0;
        reflectance = albedo;
    } else {
        metallic = 0.0;
        reflectance = vec3(specularData.g);
    }
    roughness = (1.0 - perceptualSmoothness) * (1.0 - perceptualSmoothness);
    emissive = specularData.a;
    if (emissive >= 254.5 / 255.0) {
        emissive = 0.0;
    }
    #else
    roughness = 1.0;
    metallic = 0.0;
    reflectance = vec3(0.0);
    emissive = 0.0;
    #endif
    #ifdef SH_WATER
    if (material == MATERIAL_WATER) {
        metallic = 1.0;
        roughness = 0.2;
    }
    #endif
}

vec3 Lighting_p_screenPos() {
    #ifdef SH_WORLD
    return vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
    #else
    return vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z + 0.38);
    #endif
}


struct View {
    vec3 screenPos;
    vec3 eyePlayerPos;
    vec3 feetPlayerPos;
    vec3 worldPos;
    vec3 viewPos;
};

View Lighting_p_view(vec3 viewPos) {
    vec3 screenPos = Lighting_p_screenPos();
    vec3 feetPlayerPos = feetFromView(viewPos);
    vec3 eyePlayerPos = eyeFromView(viewPos);
    vec3 worldPos = worldFromFeet(feetPlayerPos);
    return View(screenPos, eyePlayerPos, feetPlayerPos, worldPos, viewPos);
}

vec4 Lighting_p_light(TexCoordsAtlas texCoord, vec4 albedo, vec3 normalWorldSpace, vec3 worldGeoNormal, vec3 skyLight, View view, vec3 sunDirection, uint material) {
    float roughness, metallic, emissive;
    vec3 reflectance;
    Lighting_p_getMaterialProperties(texCoord, albedo.rgb, material, roughness, metallic, reflectance, emissive);

    float normalDotSun = max(dot(normalWorldSpace, sunDirection), 0.0);
    vec3 shadow;
    if (normalDotSun == 0.0) {
        shadow = vec3(0.0);
    } else {
        shadow = shadowColorMultiplier(view.screenPos, view.feetPlayerPos, worldGeoNormal, skyLight);
    }

    float trueShadowFade = min(shadowFade, 1.0 - rainStrength);

    shadow *= trueShadowFade;

    vec4 emission = vec4(albedo.rgb * emissive, emissive);
    vec3 celestialBody;
    if (timeAngle < nightStart || timeAngle > nightEnd) {
        celestialBody = sunReflectionColor * sunReflectionIntensity;
    } else {
        celestialBody = moonReflectionColor * moonReflectionIntensity;
    }
    vec3 brdfRaw = PBR_brdf(sunDirection, normalize(-view.eyePlayerPos), roughness, normalWorldSpace, albedo.rgb, metallic, reflectance, celestialBody) * shadow;
    float brdfIntensity = luminance(brdfRaw);
    return max(emission, vec4(brdfRaw, clamp(brdfIntensity, 0.0, 1.0)));
}

vec3 Lighting_p_touchLight(vec3 feetPlayerPos) {
    vec3 headPos = feetPlayerPos * vec3(1.0, 0.5, 1.0) + vec3(0.0, 0.3, 0.0);
    float headDist = length(headPos) * 0.5;
    float touchLightStrength = 1.0 - clamp(headDist * headDist, 0.0, 1.0);
    vec3 touchLight = vec3(0.1) * touchLightStrength;
    return touchLight;
}

vec3 Lighting_p_ambient(vec3 albedo, vec3 feetPlayerPos, vec3 worldGeoNormal, vec3 normalWorldSpace, vec3 skyLight) {
    vec3 ambientLightDirection = worldGeoNormal;
    vec3 blockLight;
    #ifdef SH_LIT
    vec3 touchLight = Lighting_p_touchLight(feetPlayerPos);
    blockLight = RPLE_blockColor().rgb;
    blockLight = max(blockLight, touchLight);
    #else
    blockLight = vec3(1.0);
    #endif

    vec3 ambientLight = (blockLight + 0.5 * skyLight) * clamp(dot(ambientLightDirection, normalWorldSpace), 0.0, 1.0);
    return albedo * ambientLight;
}

vec4 Lighting_p_pbr(TexCoordsAtlas texCoord, mat3 tbn, vec3 worldGeoNormal, vec4 albedo, View view, vec3 sunDirection, vec3 viewDirTexSpace, uint material) {
    float ao;
    vec3 normalWorldSpace;
    #ifdef SH_WATER
    if (material == MATERIAL_WATER) {
        vec2 waterSurface = Water_getNormal(noisetex, view.worldPos, view.eyePlayerPos, viewDirTexSpace, worldGeoNormal, length(view.eyePlayerPos));
        normalWorldSpace = Lighting_p_worldNormalFromSurface(tbn, waterSurface, worldGeoNormal);
        ao = 1.0;
    } else
    #endif
    if (material == MATERIAL_TEXT) {
        normalWorldSpace = worldGeoNormal;
        ao = 1.0;
    } else
    {
        normalWorldSpace = Lighting_p_getNormalFromTexture(texCoord, tbn, worldGeoNormal, ao);
    }
    vec3 skyLight;
    #ifdef SH_LIT
    skyLight = RPLE_skyColor().rgb;
    #else
    skyLight = vec3(1.0);
    #endif
    vec4 ambient = vec4(Lighting_p_ambient(albedo.rgb, view.feetPlayerPos, worldGeoNormal, normalWorldSpace, skyLight), albedo.a);
    vec4 pbr = Lighting_p_light(texCoord, albedo, normalWorldSpace, worldGeoNormal, skyLight, view, sunDirection, material);
    float alpha;
    #ifdef SH_WATER
    alpha = max(albedo.a, max(ambient.a, pbr.a));
    #else
    alpha = albedo.a;
    #endif
    return vec4(ao * (ambient.rgb + pbr.rgb), alpha);
}

#ifdef SH_TERRAIN
const float Lighting_p_cc_exp = 0.66;
const float Lighting_p_cc_x = pow(1.0 / 0.6, Lighting_p_cc_exp);
const float Lighting_p_cc_z = pow(1.0 / 0.8, Lighting_p_cc_exp);
const float Lighting_p_cc_yn = pow(1.0 / 0.5, Lighting_p_cc_exp);
#endif
float Lighting_p_vanillaColorCorrection(vec3 worldGeoNormal) {
    #ifdef SH_TERRAIN
    if (worldGeoNormal.x < -0.99 || worldGeoNormal.x > 0.99) {
        return Lighting_p_cc_x;
    }

    if (worldGeoNormal.z < -0.99 || worldGeoNormal.z > 0.99) {
        return Lighting_p_cc_z;
    }

    if (worldGeoNormal.y < -0.99) {
        return Lighting_p_cc_yn;
    }
    #endif
    return 1.0;
}

#ifdef SH_TEXTURED
#define SH_LIGHT_INT_TEXTURED_OR_LIT
#endif
#ifdef SH_LIT
#define SH_LIGHT_INT_TEXTURED_OR_LIT
#endif
#ifdef SH_ENTITY
#define SH_ENTITY_OR_BLOCK
#endif
#ifdef SH_BLOCK
#define SH_ENTITY_OR_BLOCK
#endif

vec4 Lighting_directional(
    TBN geo,
    TexCoordsLocal texCoords,
    vec4 baseColor,
    vec3 viewPos,
    uint material
) {
    vec4 color;
    mat3 tbnGeo = TBN_as_mat3(geo);
    TBN world = TBN_mul(gbufferModelViewInverse, geo);
    mat3 tbnWorld = TBN_as_mat3(world);
    View view = Lighting_p_view(viewPos);
    vec4 albedo;
    TexCoordsAtlas texCoord;
    #ifdef SH_LIGHT_INT_TEXTURED_OR_LIT
    vec3 sunDirection = normalize(gbufferModelViewInverse * vec4(shadowLightPosition.xyz, 0)).xyz;
    vec3 viewDirTexSpace = (tbnGeo * viewPos).xyz;
    #endif
    #ifdef SH_ENTITY_OR_BLOCK
    if (texCoords.dcdy == vec2(0.0) && texCoords.dcdx == vec2(0.0)) {
        return baseColor;
    } else if (textureSize(texture, 0).y == textTextureHeight) {
        #endif
        #ifdef SH_ENTITY
        if (texCoords.bounds == vec4(0.0)) {
            texCoord = TexCoordsAtlas(texCoords.pos, texCoords.dcdx, texCoords.dcdy);
        } else {
            texCoord = TexCoordsAtlas_fromLocalDirect(texCoords);
        }
        return baseColor * TexCoordsAtlas_sample(texture, texCoord);
        #endif
        #ifdef SH_BLOCK
        material = MATERIAL_TEXT;
        #endif
        #ifdef SH_ENTITY_OR_BLOCK
    }
    #endif
    #ifdef SH_TEXTURED
    {
        vec3 sunDirTexSpace = (tbnWorld * sunDirection).xyz;
        float dist = length(view.eyePlayerPos);
        float depth;
        texCoord = Parallax_get(texture, normalTex, texCoords, viewDirTexSpace, dist, depth, sunDirTexSpace, material);
        albedo = TexCoordsAtlas_sample(texture, texCoord);
        albedo.rgb *= 1 - depth * parallaxDepthShadeIntensity;
    }
    #else
    texCoord = TexCoordsAtlas(vec2(0.0), vec2(0.0), vec2(0.0));
    albedo = vec4(1.0);
    #endif
    #ifdef SH_LIT
    albedo.rgb *= Lighting_p_vanillaColorCorrection(world.normal);
    albedo.rgb *= baseColor.rgb * baseColor.a;
    color = Lighting_p_pbr(texCoord, tbnWorld, world.normal, albedo, view, sunDirection, viewDirTexSpace, material);
    #else
    color = albedo;
    #endif
    return color;
}

#endif