#version 460 compatibility
#define SH_TEXTURED
#define SH_LIT
#define SH_WORLD
#define SH_BLOCK
#include "/frag/common.glsl"