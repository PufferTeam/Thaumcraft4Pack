#ifndef INC_SETTINGS
#define INC_SETTINGS
// Exposed in the GUI

#define ABOUT 0 //[0]
#define ABOUT2 0 //[0]

// Generic

// dont change these 2
const float nightStart = 12780.0 / 24000.0;
const float nightEnd = 23220.0 / 24000.0;
const float dayNightCrossFade = 1000.0 / 24000.0;

// Shadows

// #define OPT_SHADOWS

const int shadowMapResolution = 4096;
const float sunPathRotation = -20.0;
const float shadowMapBias = 0.5;
const float shadowMapZScale = 0.25;

const float shadowCheckSurfaceNormalBias = 0.01;
const float shadowCheckDepthBias = 0.001;
const float shadowCheckPlayerDistanceBias = 0.000001;
const float shadowDistanceHighQuality = 128.0;
const float shadowDistanceFadeStart = 96.0;
const float shadowDistance = 128.0;

// Parallax

const float parallaxFadeStart = 16.0;
const float parallaxFadeEnd = 64.0;
const float parallaxDepth = 0.25;
const int parallaxLayers = 256;
const float parallaxDepthShadeIntensity = 0.5;

// PBR

const vec3 sunReflectionColor = vec3(0.36, 0.3, 0.25);
const float sunReflectionIntensity = 2.0;

const vec3 moonReflectionColor = vec3(0.25, 0.3, 0.36);
const float moonReflectionIntensity = 1.0;

// Hidden

#define TONEMAP 6 //[1 2 3 4 5 6]

#define TonemapExposure 1.2 //[1.0 1.2 1.4 2.0 2.8 4.0 5.6 8.0 11.3 16.0]
#define TonemapWhiteCurve 2.0 //[1.0 1.5 2.0 2.5 3.0 3.5 4.0]
#define TonemapLowerCurve 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]
#define TonemapUpperCurve 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]

#define BSLSaturation 1.20 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
#define BSLVibrance 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

#define SWIZZLE rgb //Channel mixing [rrr rrg rrb rgr rgg rgb rbr rbg rbb grr grg grb ggr ggg ggb gbr gbg gbb brr brg brb bgr bgg bgb bbr bbg bbb]

// #define lensMonochrome
#define lMonoRed 255 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0 185.0 190.0 195.0 200.0 205.0 210.0 215.0 220.0 225.0 230.0 235.0 240.0 245.0 250.0 255.0]
#define lMonoGreen 105 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0 185.0 190.0 195.0 200.0 205.0 210.0 215.0 220.0 225.0 230.0 235.0 240.0 245.0 250.0 255.0]
#define lMonoBlue 205 //[0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0 185.0 190.0 195.0 200.0 205.0 210.0 215.0 220.0 225.0 230.0 235.0 240.0 245.0 250.0 255.0]
#define lMonoAlpha 0.75 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

const int noiseTextureResolution = 512;
const int textTextureHeight = 2048;

#endif