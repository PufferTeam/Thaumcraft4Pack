#ifndef INC_MATH
#define INC_MATH

float rand(float n) {
    return fract(sin(n) * 43758.5453123);
}
float rand2(vec2 n) {
    return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
}

vec2 rotate(vec2 v, float a) {
    float s = sin(a);
    float c = cos(a);
    mat2 m = mat2(c, s, -s, c);
    return m * v;
}

float luminance(vec3 color) {
    return dot(color,vec3(0.299, 0.587, 0.114));
}

#endif