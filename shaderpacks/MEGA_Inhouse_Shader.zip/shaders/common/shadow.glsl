#ifndef INC_SHADOW_COMMON
#define INC_SHADOW_COMMON

#include "/common/settings.glsl"

vec4 shadowClipDistort(vec4 shadowClip) {
    float distanceFromPlayer = length(shadowClip.xy);
    shadowClip.xy /= (shadowMapBias + distanceFromPlayer);
    shadowClip.z *= shadowMapZScale;
    return shadowClip;
}

#endif