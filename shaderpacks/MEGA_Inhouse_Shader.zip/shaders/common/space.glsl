/*
Spaces:

screen - screenspace coordinates, 0 - 1
ndc - normalized device coordinates, -1 - 1
view - camera forward is Z-
eye - camera is at center, world-space orientation
feet - player head is at center, world-space orientation
world - world origin is at center, camera position moves
*/
#ifndef INC_SPACE
#define INC_SPACE
#include "/common/matrices.glsl"
uniform vec3 cameraPosition;

vec3 projectAndDivide(mat4 projectionMatrix, vec3 position) {
    vec4 homogenousPos = projectionMatrix * vec4(position, 1.0);
    return homogenousPos.xyz / homogenousPos.w;
}

vec3 ndcFromScreen(vec3 screenPos) {
    return screenPos * 2.0 - 1.0;
}

vec3 screenFromNdc(vec3 ndcPos) {
    return ndcPos * 0.5 + 0.5;
}

vec3 viewFromNdc(vec3 ndcPos) {
    return projectAndDivide(gbufferProjectionInverse, ndcPos);
}

vec3 ndcFromView(vec3 viewPos) {
    return projectAndDivide(gbufferProjection, viewPos);
}

vec3 ndcFromClip(vec4 clipPos) {
    return clipPos.xyz / clipPos.w;
}

vec3 viewFromClip(vec4 clipPos) {
    return (gbufferProjectionInverse * clipPos).xyz;
}

vec4 clipFromView(vec3 viewPos) {
    #ifdef VSH
    return gl_ProjectionMatrix * vec4(viewPos, 1.0);
    #else
    return gbufferProjection * vec4(viewPos, 1.0);
    #endif
}

vec3 feetFromView(vec3 viewPos) {
    return (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
}

vec3 viewFromFeet(vec3 feetPos) {
    return (gbufferModelView * vec4(feetPos, 1.0)).xyz;
}

vec3 worldFromFeet(vec3 feetPos) {
    return feetPos + cameraPosition;
}

vec3 feetFromWorld(vec3 worldPos) {
    return worldPos - cameraPosition;
}

vec3 eyeFromView(vec3 viewPos) {
    return mat3(gbufferModelViewInverse) * viewPos;
}

vec3 viewFromEye(vec3 eyePos) {
    return mat3(gbufferModelView) * eyePos;
}

vec3 eyeFromFeet(vec3 feetPos) {
    return feetPos - gbufferModelViewInverse[3].xyz;
}

vec3 feetFromEye(vec3 eyePos) {
    return eyePos + gbufferModelViewInverse[3].xyz;
}
#endif