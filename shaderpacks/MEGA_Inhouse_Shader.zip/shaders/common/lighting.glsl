#ifndef INC_LIGHTING_COMMON
#define INC_LIGHTING_COMMON
struct TBN {
    vec3 tangent;
    vec3 bitangent;
    vec3 normal;
};


mat3 TBN_as_mat3(TBN tbn) {
    return transpose(mat3(tbn.tangent, tbn.bitangent, tbn.normal));
}


struct TexCoordVsh {
    vec2 pos;
    vec4 bounds;
};

struct TexCoordsLocal {
    vec2 pos;
    vec4 bounds;
    vec2 dcdx;
    vec2 dcdy;
};

struct TexCoordsAtlas {
    vec2 pos;
    vec2 dcdx;
    vec2 dcdy;
};

TexCoordsAtlas TexCoordsAtlas_fromLocalDirect(TexCoordsLocal coords) {
    TexCoordsAtlas result;
    result.pos = coords.pos * coords.bounds.pq + coords.bounds.st;
    result.dcdx = coords.dcdx;
    result.dcdy = coords.dcdy;
    return result;
}

TexCoordsAtlas TexCoordsAtlas_fromLocalClamp(TexCoordsLocal coords) {
    TexCoordsAtlas result;
    result.pos = clamp(coords.pos, 0.0, 1.0) * coords.bounds.pq + coords.bounds.st;
    result.dcdx = coords.dcdx;
    result.dcdy = coords.dcdy;
    return result;
}

TexCoordsAtlas TexCoordsAtlas_fromLocalFract(TexCoordsLocal coords) {
    TexCoordsAtlas result;
    result.pos = fract(coords.pos) * coords.bounds.pq + coords.bounds.st;
    result.dcdx = coords.dcdx;
    result.dcdy = coords.dcdy;
    return result;
}

vec4 TexCoordsAtlas_sample(in sampler2D tex, TexCoordsAtlas coords) {
    return textureGrad(tex, coords.pos, coords.dcdx, coords.dcdy);
}

vec4 TexCoordsLocal_sampleDirect(in sampler2D tex, TexCoordsLocal coords) {
    return TexCoordsAtlas_sample(tex, TexCoordsAtlas_fromLocalDirect(coords));
}


vec4 TexCoordsLocal_sampleClamp(in sampler2D tex, TexCoordsLocal coords) {
    return TexCoordsAtlas_sample(tex, TexCoordsAtlas_fromLocalClamp(coords));
}


vec4 TexCoordsLocal_sampleFract(in sampler2D tex, TexCoordsLocal coords) {
    return TexCoordsAtlas_sample(tex, TexCoordsAtlas_fromLocalFract(coords));
}
#endif