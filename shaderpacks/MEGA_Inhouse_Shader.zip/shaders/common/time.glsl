#ifndef INC_TIME_COMMON
#define INC_TIME_COMMON
uniform float frameTimeCounter;
#endif
