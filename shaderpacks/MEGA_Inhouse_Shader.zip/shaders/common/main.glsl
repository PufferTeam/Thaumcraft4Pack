#include "/common/lighting.glsl"

struct Info {
    TBN tbn;
    #ifdef SH_TEXTURED
    TexCoordVsh texCoords;
    #endif
    vec4 color;
    vec3 viewPos;
};