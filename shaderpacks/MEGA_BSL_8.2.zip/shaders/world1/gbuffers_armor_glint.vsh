/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 130 

#define END
#define VSH

#include "/program/gbuffers_armor_glint.glsl"
