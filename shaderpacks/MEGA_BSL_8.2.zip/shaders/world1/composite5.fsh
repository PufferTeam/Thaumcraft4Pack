/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 130 

#extension GL_ARB_shader_texture_lod : enable

#define END
#define FSH

#include "/program/composite5.glsl"
