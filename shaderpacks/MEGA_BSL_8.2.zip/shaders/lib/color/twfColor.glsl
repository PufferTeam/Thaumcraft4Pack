vec4 twfColSqrt = vec4(vec3(TWF_R, TWF_G, TWF_B) / 255.0, 1.0) * TWF_I;
vec4 twfCol = twfColSqrt * twfColSqrt;