/*
    This helper library provides functions for integrating RPLE with a given shader.

    // SKILL_ISSUE: Additional documentation
*/

void getLightMapCoords(out vec2 redLightMapCoord, out vec2 greenLightMapCoord, out vec2 blueLightMapCoord);
void getBrightness(out vec4 blockBrightness, out vec4 skyBrightness);
float luminance(in vec3 brightness);

/*
    Gets the Light Map coordinated from RPLE.
*/
void getLightMapCoords(out vec2 redLightMapCoord, out vec2 greenLightMapCoord, out vec2 blueLightMapCoord) {
    redLightMapCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    greenLightMapCoord = (gl_TextureMatrix[6] * gl_MultiTexCoord6).st;
    blueLightMapCoord = (gl_TextureMatrix[7] * gl_MultiTexCoord7).st;
}

/*
    Gets the brightness based the coordinates provied by RPLE.

    The fourth element in each vector is the perceived intensity.
*/
void getBrightness(out vec4 blockBrightness, out vec4 skyBrightness) {
    vec2 redLightMapCoord;
    vec2 greenLightMapCoord;
    vec2 blueLightMapCoord;
    getLightMapCoords(redLightMapCoord, greenLightMapCoord, blueLightMapCoord);

    blockBrightness.r = redLightMapCoord.s;
    blockBrightness.g = greenLightMapCoord.s;
    blockBrightness.b = blueLightMapCoord.s;
    blockBrightness.w = luminance(blockBrightness.rgb);
    blockBrightness.rgb /= blockBrightness.w;
    blockBrightness.rgb *= blockBrightness.rgb;

    skyBrightness.r = redLightMapCoord.t;
    skyBrightness.g = greenLightMapCoord.t;
    skyBrightness.b = blueLightMapCoord.t;
    skyBrightness.w = luminance(skyBrightness.rgb);
    skyBrightness.rgb /= skyBrightness.w;
    skyBrightness.rgb *= skyBrightness.rgb;
}

/*
    Calculates the perceived brightness intensity using a weighted average.
*/
float luminance(in vec3 brightness) {
    return max(brightness.r, max(brightness.g, brightness.b));
}
