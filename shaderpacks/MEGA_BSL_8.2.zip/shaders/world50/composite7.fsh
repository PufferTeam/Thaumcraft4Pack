/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 130 

#extension GL_ARB_shader_texture_lod : enable

#define TWF
#define FSH

#include "/program/composite7.glsl"
