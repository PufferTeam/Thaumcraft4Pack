/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 130 

#define TWF
#define VSH

#include "/program/composite2.glsl"
