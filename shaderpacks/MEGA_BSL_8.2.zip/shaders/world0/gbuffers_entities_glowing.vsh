/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 130 

#define OVERWORLD
#define VSH

#include "/program/gbuffers_entities_glowing.glsl"
