/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 130 

#define NETHER
#define VSH

#include "/program/composite7.glsl"
