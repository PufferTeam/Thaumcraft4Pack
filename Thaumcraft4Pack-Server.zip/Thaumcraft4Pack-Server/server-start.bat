@echo off
SET PACK_TOML=https://raw.githubusercontent.com/PufferTeam/Thaumcraft4Pack/refs/heads/beta/pack.toml

SET JAVA_ARGS=-Dfile.encoding^=UTF-8 -Djava.system.class.loader^=com.gtnewhorizons.retrofuturabootstrap.RfbSystemClassLoader --add-opens java.base/java.io^=ALL-UNNAMED --add-opens java.base/java.lang.invoke^=ALL-UNNAMED --add-opens java.base/java.lang.ref^=ALL-UNNAMED --add-opens java.base/java.lang.reflect^=ALL-UNNAMED --add-opens java.base/java.lang^=ALL-UNNAMED --add-opens java.base/java.net.spi^=ALL-UNNAMED --add-opens java.base/java.net^=ALL-UNNAMED --add-opens java.base/java.nio.channels^=ALL-UNNAMED --add-opens java.base/java.nio.charset^=ALL-UNNAMED --add-opens java.base/java.nio.file^=ALL-UNNAMED --add-opens java.base/java.nio^=ALL-UNNAMED --add-opens java.base/java.text^=ALL-UNNAMED --add-opens java.base/java.time.chrono^=ALL-UNNAMED --add-opens java.base/java.time.format^=ALL-UNNAMED --add-opens java.base/java.time.temporal^=ALL-UNNAMED --add-opens java.base/java.time.zone^=ALL-UNNAMED --add-opens java.base/java.time^=ALL-UNNAMED --add-opens java.base/java.util.concurrent.atomics^=ALL-UNNAMED --add-opens java.base/java.util.concurrent.locks^=ALL-UNNAMED --add-opens java.base/java.util.jar^=ALL-UNNAMED --add-opens java.base/java.util.zip^=ALL-UNNAMED --add-opens java.base/java.util^=ALL-UNNAMED --add-opens java.base/jdk.internal.loader^=ALL-UNNAMED --add-opens java.base/jdk.internal.misc^=ALL-UNNAMED --add-opens java.base/jdk.internal.ref^=ALL-UNNAMED --add-opens java.base/jdk.internal.reflect^=ALL-UNNAMED --add-opens java.base/sun.nio.ch^=ALL-UNNAMED --add-opens java.desktop/com.sun.imageio.plugins.png^=ALL-UNNAMED --add-opens java.desktop/sun.awt.image^=ALL-UNNAMED --add-opens java.desktop/sun.awt^=ALL-UNNAMED --add-opens java.sql.rowset/javax.sql.rowset.serial^=ALL-UNNAMED --add-opens jdk.dynalink/jdk.dynalink.beans^=ALL-UNNAMED --add-opens jdk.naming.dns/com.sun.jndi.dns^=ALL-UNNAMED,java.naming

SET SP_1=#Minecraft server properties
SET SP_2=allow-flight^=true
SET SP_3=allow-nether^=true
SET SP_4=announce-player-achievements^=true
SET SP_5=difficulty^=1
SET SP_6=enable-command-block^=false
SET SP_7=enable-query^=false
SET SP_8=enable-rcon^=false
SET SP_9=force-gamemode^=false
SET SP_10=gamemode^=0
SET SP_11=generate-structures^=true
SET SP_12=generator-settings^=
SET SP_13=hardcore^=false
SET SP_14=level-name^=world
SET SP_15=level-seed^=4373006400381561264
SET SP_16=level-type^=BIOMESOP
SET SP_17=max-build-height^=256
SET SP_18=max-players^=20
SET SP_19=max-tick-time^=90000
SET SP_20=motd^=^\u00a75^\u00a7lThaumcraft:^\u00a78 Unseen Realm
SET SP_21=online-mode^=false
SET SP_22=op-permission-level^=4
SET SP_23=player-idle-timeout^=0
SET SP_24=pvp^=true
SET SP_25=resource-pack^=
SET SP_26=server-ip^=
SET SP_27=server-port^=25565
SET SP_28=snooper-enabled^=false
SET SP_29=spawn-animals^=true
SET SP_30=spawn-monsters^=true
SET SP_31=spawn-npcs^=true
SET SP_32=spawn-protection^=16
SET SP_33=view-distance^=10
SET SP_34=white-list^=false

SET EU_1=#Mojang EULA
SET EU_2=eula^=true

echo Downloading: Required Packwiz Files
java -jar packwiz-installer-bootstrap.jar -g -s server %PACK_TOML%
echo Downloaded: Required Packwiz Files
IF exist libraries\ ( echo Skipping: Forge Server Jar already installed ) ELSE ( echo Installing: Forge Server Jar && java -jar forge-1.7.10-10.13.4.1614-1.7.10-installer.jar --installServer && echo Installed: Forge Server Jar)
IF exist server.properties ( echo Skipping: server.properties already exists ) ELSE ( echo Creating: server.properties && (Echo(%SP_1%) 1>> server.properties && (Echo(%SP_2%) 1>> server.properties && (Echo(%SP_3%) 1>> server.properties && (Echo(%SP_4%) 1>> server.properties && (Echo(%SP_5%) 1>> server.properties && (Echo(%SP_6%) 1>> server.properties && (Echo(%SP_7%) 1>> server.properties && (Echo(%SP_8%) 1>> server.properties && (Echo(%SP_9%) 1>> server.properties && (Echo(%SP_10%) 1>> server.properties && (Echo(%SP_11%) 1>> server.properties && (Echo(%SP_12%) 1>> server.properties && (Echo(%SP_13%) 1>> server.properties && (Echo(%SP_14%) 1>> server.properties && (Echo(%SP_15%) 1>> server.properties && (Echo(%SP_16%) 1>> server.properties && (Echo(%SP_17%) 1>> server.properties && (Echo(%SP_18%) 1>> server.properties && (Echo(%SP_19%) 1>> server.properties && (Echo(%SP_20%) 1>> server.properties && (Echo(%SP_21%) 1>> server.properties && (Echo(%SP_22%) 1>> server.properties && (Echo(%SP_23%) 1>> server.properties && (Echo(%SP_24%) 1>> server.properties && (Echo(%SP_25%) 1>> server.properties && (Echo(%SP_26%) 1>> server.properties && (Echo(%SP_27%) 1>> server.properties && (Echo(%SP_28%) 1>> server.properties && (Echo(%SP_29%) 1>> server.properties && (Echo(%SP_30%) 1>> server.properties && (Echo(%SP_31%) 1>> server.properties && (Echo(%SP_32%) 1>> server.properties && (Echo(%SP_33%) 1>> server.properties && (Echo(%SP_34%) 1>> server.properties && echo Created: server.properties)
IF exist eula.txt ( echo Skipping: eula.txt already exists ) ELSE ( echo Creating: eula.txt && (Echo(%EU_1%) 1>> eula.txt && (Echo(%EU_2%) 1>> eula.txt && echo Created: eula.txt)
IF exist java-args.txt ( echo Skipping: java-args.txt already exists ) ELSE ( echo Creating: java-args.txt && (Echo(%JAVA_ARGS%) 1>> java-args.txt && echo Created: java-args.txt)

:restart
echo Running Server
java -Xmx6G -Xms6G @java-args.txt -jar lwjgl3ify-forgePatches.jar nogui
echo Server Stopped
goto :restart

pause